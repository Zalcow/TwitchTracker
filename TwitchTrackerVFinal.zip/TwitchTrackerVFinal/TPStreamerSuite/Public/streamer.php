<?php

// include db
include __DIR__ . '/../Database/db.php';
// include model
include __DIR__ . '/../Model/streamer.php';
// include view
include __DIR__ . '/../View/streamer.php';

/**
 * render a 404 page
 */
function page_not_found()
{
    header("HTTP/1.0 404 Not Found "); //On définit la page comme étant une page 404 au sein de l’entête
    include __DIR__ . '/../view/404.html'; // On ajoute la vue de la page 404
    die(); // arrête l’exécution du script
}
