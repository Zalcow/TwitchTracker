<?php
$query = $dbh->prepare('SELECT * from streamers'); // $dbh est la connexion initialisée dans le fichier db.php
$query->execute();
$streamer = $query->fetchAll();

$query2 = $dbh->prepare('SELECT * from streamers_stats'); // $dbh est la connexion initialisée dans le fichier db.php
$query2->execute();
$streamer2 = $query2->fetchAll();
