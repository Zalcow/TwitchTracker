<!DOCTYPE HTML>
<html>

<head>
    <meta http-equiv="content-type" content="text/html;charset=utf-8" />
    <link rel="stylesheet" href="style.css"/>
    <title>Information Streamer</title>
</head>

<body>
    <h1 id="infostream">Informations Streamer : </h1>
          
          <div id= "infos"> 
              <p>Id : <?=$streamer[$streamerId]["id"]; ?></p>
              <P>Nom : <?= $streamer[$streamerId]["name"]; ?></p>   
              <p>Minutes Streamé : <?= $streamer2[$streamerId]["minutes_streamed"]; ?></p>
              <p>Rank : <?= $streamer2[$streamerId]["rank"]; ?></p>
              <p>Moyenne Viewers : <?= $streamer2[$streamerId]["avg_viewers"]; ?></p>
              <p>Max Viewers : <?= $streamer2[$streamerId]["max_viewers"]; ?></p>
              <p>Heures Visionnées : <?= $streamer2[$streamerId]["hours_watched"]; ?></p>
              <p>Followers : <?= $streamer2[$streamerId]["followers"]; ?></p>
              <p>Vues : <?= $streamer2[$streamerId]["views"]; ?></p>
              <p>Total de Followers : <?= $streamer2[$streamerId]["followers_total"]; ?></p>
              <p>Total de vues : <?= $streamer2[$streamerId]["views_total"]; ?></p>
              <div id="imgstream"><img src="\image\<?=$streamerId?>.jpg"></div>
          </div>
    <br>

    <div class="chart-container" style="position: relative; height:300px; width:600px; margin-left:38%">
        <canvas id="graphique"></canvas>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <script>
  const labels = [
    'Mars',
    'Avril',
    'Mai'
  ];

  const data = {
    labels: labels,
    datasets: [{
      label: 'Nombre de vues',
      backgroundColor: 'rgb(255, 99, 132)',
      borderColor: 'rgb(255, 99, 132)',
      data: [<?php if(array_key_exists("0", $streamer3)) {echo $streamer3[0]["views"];} else {echo 0;}?>,
             <?php if(array_key_exists("1", $streamer3)) {echo $streamer3[1]["views"];} else {echo 0;}?>,
             <?php if(array_key_exists("2", $streamer3)) {echo $streamer3[2]["views"];} else {echo 0;}?>
            ],
    }]
  };

  const config = {
    type: 'line',
    data: data,
    options: {}
  };
</script>

<script>
  const myChart = new Chart(document.getElementById('graphique'),config);
</script>

    <a href="/streamer.php">Retour</a>
</body>

</html>