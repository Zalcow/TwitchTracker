<!-- ~/php/tp1/view/cities.php -->
<!DOCTYPE HTML>
<html>

<head>
    <meta http-equiv="content-type" content="text/html;charset=utf-8" />
    <link rel="stylesheet" href="style.css"/>
    <title>Streamer Tracker</title>
    
</head>

<script type="text/javascript">
    function ShowHideBox(box,streamer)
    {
        if (box.checked)
        {
            document.getElementById(streamer).style.display = "flex";
        }
        else
        {
            document.getElementById(streamer).style.display = "none";
        }
    }
</script>

<body>
    <h1>Twitch Tracker</h1>
    <h2>Vos streamers préférés</h2>
        <div id="page1">
            <?php foreach ($streamer as $streamerId => $streamerpage) : ?>
                <div class="nom_streamer">
                    <div class="streamer" id='<?=$streamerId?>'><p><a href="streamerpage.php?id=<?= $streamerId; ?>"><img src="\image\<?=$streamerId?>.jpg"><?=$streamer[$streamerId]["name"]?></p></div>
                    <p class="chekbox"> <input type="checkbox" onclick="ShowHideBox(this, '<?=$streamerId?>')" Checked></p>
                </div>
            <?php endforeach; ?>
        </div>
        <div id="img1"><img src="\image\twitch.png"></div>
</body>

</html>