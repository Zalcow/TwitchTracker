<!DOCTYPE HTML>
<html>

<head>
    <meta http-equiv="content-type" content="text/html;charset=utf-8" />
    <link rel="stylesheet" href="style.css"/>
    <title>Information Streamer</title>
</head>

<body>
    <h1>Information Streamer : </h1>
    <table>
        <tr>
            <td>Id : <?=$streamer[$streamerId]["id"]; ?></td>   
        </tr>   
        <tr>
            <td>Nom : <?= $streamer[$streamerId]["name"]; ?></td>
        </tr>
        <tr>
            <td> Minutes Streamé : <?= $streamer2[$streamerId]["minutes_streamed"]; ?></td>
            <td> Rank : <?= $streamer2[$streamerId]["rank"]; ?></td>
            <td> Moyenne Viewers : <?= $streamer2[$streamerId]["avg_viewers"]; ?></td>
            <td> Max Viewers : <?= $streamer2[$streamerId]["max_viewers"]; ?></td>
            <td> Heures Visionnées : <?= $streamer2[$streamerId]["hours_watched"]; ?></td>
            <td> Followers : <?= $streamer2[$streamerId]["followers"]; ?></td>
            <td> Vues : <?= $streamer2[$streamerId]["views"]; ?></td>
            <td> Total de Followers : <?= $streamer2[$streamerId]["followers_total"]; ?></td>
            <td> Total de vues : <?= $streamer2[$streamerId]["views_total"]; ?></td>
        </tr>
    </table>
    <br>

    <div class="chart-container" style="position: relative; height:200px; width:400px">
        <canvas id="graphique"></canvas>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <script>
  const labels = [
    'Mars',
    'Avril',
    'Mai'
  ];

  const data = {
    labels: labels,
    datasets: [{
      label: 'Nombre de vues',
      backgroundColor: 'rgb(255, 99, 132)',
      borderColor: 'rgb(255, 99, 132)',
      data: [<?php if(array_key_exists("0", $streamer3)) {echo $streamer3[0]["views"];} else {echo null;}?>,
             <?php if(array_key_exists("1", $streamer3)) {echo $streamer3[1]["views"];} else {echo null;}?>,
             <?php if(array_key_exists("2", $streamer3)) {echo $streamer3[2]["views"];} else {echo null;}?>
            ],
    }]
  };

  const config = {
    type: 'line',
    data: data,
    options: {}
  };
</script>

<script>
  const myChart = new Chart(document.getElementById('graphique'),config);
</script>

    <a href="/streamer.php">Retour</a>
</body>

</html>